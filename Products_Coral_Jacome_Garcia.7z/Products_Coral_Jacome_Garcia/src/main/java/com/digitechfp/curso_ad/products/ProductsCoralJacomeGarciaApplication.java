package com.digitechfp.curso_ad.products;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductsCoralJacomeGarciaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductsCoralJacomeGarciaApplication.class, args);
    }

}
